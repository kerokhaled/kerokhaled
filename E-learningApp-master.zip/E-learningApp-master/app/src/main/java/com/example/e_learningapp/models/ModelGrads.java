package com.example.e_learningapp.models;

public class ModelGrads {

    int quizGrade  ;
    int attendanceGrade ;


    public int getQuizGrade() {
        return quizGrade;
    }

    public void setQuizGrade(int quizGrade) {
        this.quizGrade = quizGrade;
    }

    public int getAttendanceGrade() {
        return attendanceGrade;
    }

    public void setAttendanceGrade(int attendanceGrade) {
        this.attendanceGrade = attendanceGrade;
    }
}
