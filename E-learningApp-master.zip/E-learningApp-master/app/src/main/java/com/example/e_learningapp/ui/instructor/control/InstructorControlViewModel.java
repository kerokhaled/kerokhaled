package com.example.e_learningapp.ui.instructor.control;


import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;


public class InstructorControlViewModel {




}
