package com.example.e_learningapp.utils;

public class Const {


    public static String userType ="" ;
    public static final String SUCCESS = "success";
    public static final String STUDENT_USER ="student";
    public static final String INSTRUCTOR_USER = "instructor";
    public static final String REF_USERS = "users";
    public static final String REF_COURSES = "courses";
    public static final String REF_INSTRUCTOR_ID = "instructorId";
    public static final String REF_COURSE_MEMBERS = "members";
    public static final String REF_ATTENDANCE = "attendance";
    public static final String REF_FILES = "courses files";
    public static final String REF_QUIZ = "courses quiz";
    public static final String REF_QUIZ_ANSWER  = "quiz answer" ;
    public static final String REF_CHATS  = "chats" ;




}
